# Afghan Cultural Design Patterns, Pashto Typography, and RTL Interfaces: A Research-Driven Implementation Guide

## Executive Summary and Objectives

This report provides a research-backed, practical guide for designing and building Pashto-language user interfaces that honor Afghan culture while meeting modern standards for usability, accessibility, and performance. It integrates color symbolism and motif meaning from Afghan material culture, typographic selection and tuning for Pashto, right-to-left (RTL) interface and asset mirroring, and culturally informed UX and accessibility practices.

Three principles shape the recommendations. First, build RTL into the core of the system rather than treating it as an after-thought—this includes document direction, layout mirroring, and iconography. Second, treat typography as an end-to-end capability: pair appropriate Pashto-capable families (e.g., Noto Sans Arabic, Noto Naskh Arabic, and Noto Kufi Arabic) with platform-consistent type scales and rendering checks. Third, integrate Afghan visual culture with restraint—use geometric and textile motifs as subtle background systems, never competing with text or core actions.

Outcomes include a color strategy anchored in cultural meaning, a font strategy for UI and long-form reading, a comprehensive RTL implementation checklist, an accessibility test matrix for RTL, and guidance for modernizing traditional motifs without compromising clarity or performance. The report concludes with an implementation roadmap and risk controls, and highlights critical information gaps—such as the need for empirical legibility testing in Afghan user contexts—that should be addressed through planned research sprints.[^1][^5][^4]



## Cultural Foundations: Colors and Motifs in Afghan Design

### Color symbolism in Afghan culture and UI translation

Color in Afghan textiles and dress carries culturally resonant meanings that can inform interface palettes. Within textiles, bold reds, deep blues, greens, yellows, and oranges predominate, creating high-chroma accents against more neutral grounds. In Afghan dress, red communicates love and vitality, green suggests growth and paradise, blue evokes sky and purity, yellow signals knowledge and wisdom, white represents peace, and black conveys strength and resilience.[^6][^7]

For digital products, translate these cultural signals into practical token systems. Use deep blues and neutral blacks as text and background bases for calm, high-contrast reading experiences; deploy red sparingly for critical alerts and calls to action that require immediate attention; use green to confirm success and progress; reserve yellow for highlights and badges where contrast can be managed; and employ black as a stabilizing element in navigation and layout scaffolding. Crucially, ensure the same semantics across both light and dark themes, and validate contrast in both.

To make this actionable for teams, Table 1 maps common Afghan UI colors to cultural meanings, recommended UI roles, and accent usage. This helps design system owners codify palette decisions that are both culturally respectful and functionally effective.

To illustrate the color-to-ui mapping at a glance, Table 1 consolidates the symbolism and practical use.

Table 1. Color symbolism and recommended UI usage
| Color | Cultural meaning (Afghan context) | Recommended UI roles | Accent usage notes |
|---|---|---|---|
| Red | Love, passion, vitality | Critical alerts, destructive actions, promotional accents | Use sparingly; ensure contrast and cultural sensitivity[^6] |
| Green | Growth, prosperity, paradise | Success states, confirmations, progress | Excellent for confirmation badges and success toasts[^6] |
| Blue | Purity, sky’s vastness | Primary navigation, info banners, text on light backgrounds | Pairs well with neutral grays for calm reading environments[^6] |
| Yellow | Knowledge, wisdom | Highlights, badges, caution states | Manage contrast; avoid large text areas[^6] |
| White | Purity, peace | Backgrounds (light theme), negative space | Avoid glare; tune paper/ink contrast for legibility[^6] |
| Black | Strength, resilience | Headlines, body text, navigation bars (dark theme) | High-contrast base; mind color、温度 in dark mode[^6] |

In practice, many Afghan textiles lean on bold reds and deep blues, with high-chroma accents that risk visual noise when translated to UI. Favor neutral grounds and desaturated accents; reserve high-chroma reds and yellows for discrete elements and data highlights, not for large surfaces. The goal is to borrow the symbolic resonance while maintaining the安静 (quiet) reading environment that Pashto text requires.[^7]

### Motifs and patterns: meanings and UI application

Afghan rugs and textiles organize meaning through geometry and symbolism: diamonds and hexagons connote protection and stability; floral motifs, including the Tree of Life, represent growth and the bridge between earthly and divine; tribal guls signal identity and lineage. These motifs are often grounded in the rhythms of daily life, landscape, and stories, and can be abstracted into digital design systems as low-contrast, repetitive background fields that support content without competing with it.[^8][^9][^10]

- Diamonds and hexagons: Use as subtle background tessellations behind content cards or in empty states. Keep the stroke light and the contrast low so they function as “visual whispering” rather than foreground decoration.
- Floral and Tree of Life: Reserve for narrative illustrations or hero backgrounds with low opacity, or in empty-state illustrations that support onboarding stories. Avoid placing floral lines under dense body text.
- Tribal and geometric borders: Employ as dividers, card outlines, or section markers. Thin, repeated borders echo textile edges and can act as lightweight navigational cues.

In all cases, use motifs as systemized patterns at multiple scales—micro (badge textures), meso (card backgrounds), macro (page scaffolds)—and test against real Pashto text to ensure no interference with readability.[^8][^10]



### Afghan Color Palettes and Cultural Motifs

For teams building a scalable design system, anchor on the palette semantics in Table 1 and then expand into theme tokens. The following table provides example palette structures and usage guidance that respect Afghan symbolism while ensuring usability across screens.

Table 2. Example Afghan-inspired UI palette mapping
| Semantic token | Example value | Usage guidance | Cultural note |
|---|---|---|---|
| text-primary | near-black (e.g., deep charcoal) | Long-form body text in light theme | Black conveys strength; ensures high contrast[^6] |
| text-secondary | deep blue-gray | Secondary text, metadata | Blue evokes calm and clarity[^6] |
| bg-default | off-white | Primary canvas | White signals peace; keep glare low[^6] |
| bg-elevated | very light gray | Cards, menus | Prevents visual fatigue in dense text |
| brand-primary | deep sky blue | Buttons, links, navigation | A muted blue aligns with blue symbolism[^6] |
| brand-accent | brick red | CTAs, highlights | Red for vitality; use sparingly[^6] |
| success | deep green | Success banners, confirmations | Green for growth and prosperity[^6] |
| warning | ochre-yellow | Warning banners, badges | Yellow for wisdom; check contrast[^6] |
| neutral | charcoal/gray scale | Dividers, surfaces | Balances stronger accents |

As a rule of thumb, let neutrals and blues form the stable base of the reading environment; reserve red and yellow for accent roles. This preserves the legibility of Pashto script while still expressing cultural color meaning.[^6][^7]

### Afghan Pattern Integration in UI Design

Motifs can be operationalized as repeatable, low-contrast pattern tiles applied at three scales, with design guardrails that ensure text and interaction clarity. Table 3 translates core motif categories into UI roles and constraints.

Table 3. Motif-to-UI pattern mapping
| Motif category | Cultural meaning | Suitable UI roles | Design constraints |
|---|---|---|---|
| Diamonds / lozenges | Protection, balance | Card background, empty-state texture | Keep opacity low; avoid under dense text[^8][^10] |
| Hexagons (“elephant’s foot”) | Strength, stability | Section dividers, dashboard panels | Use thin strokes; maintain consistent rhythm[^8] |
| Tribal guls | Identity, lineage | Accent stripes in headers/footers | Limit to small surfaces; do not frame body text[^8][^9] |
| Floral (flowers, leaves) | Growth, life | Hero illustrations, onboarding visuals | Avoid busy patterns behind paragraphs[^10] |
| Tree of Life | Bridge earth–heaven | Narrative spot illustrations | Reserve for non-text areas[^10] |

In implementation, create pattern libraries as SVG tiles with tuned opacity and contrast, and integrate them as design tokens (e.g., pattern-scale, pattern-opacity). Aesthetically, draw on the structural clarity of Islamic geometric systems while remaining sensitive to Afghan textile traditions—particularly in border treatments and field patterns—to achieve contemporary, respectful UI styling.[^9]



## Pashto Typography: Font Selection, Rendering, and Optimization

### Selecting Pashto-capable fonts for UI vs. editorial

Pashto is written in a cursive Arabic script with contextual letter forms and diacritics. The right font must render these forms crisply, provide readable diacritics, and offer multiple weights for hierarchy. The Noto family provides broad script coverage and consistent metrics across platforms: Noto Sans Arabic for modern UI and body text, Noto Naskh Arabic for long-form reading, and Noto Kufi Arabic for display and labels that benefit from a more geometric presence.[^1][^2][^3][^12][^13]

To guide selection, Table 4 compares commonly used Pashto-capable families and their ideal use cases.

Table 4. Pashto-capable fonts comparison
| Font | Style | Weights | Best use | License |
|---|---|---|---|---|
| Noto Sans Arabic | Humanist sans | Multiple (Thin–Black) | UI labels, controls, body text on screen | Open source (SIL OFL)[^1][^13] |
| Noto Naskh Arabic | Naskh serif | Multiple (suited to long-form) | Articles, documentation, long passages | Open source (SIL OFL)[^2][^13] |
| Noto Kufi Arabic | Geometric Kufi | Multiple | Display headlines, navigational titles | Open source (SIL OFL)[^3][^13] |
| AGT Pashto Nastaliq | Nastaliq | Traditional styles available | Literary/poetic headings, brand expressives | Free download (check license)[^14] |
| Scheherazade New | Nastaliq-inspired | Multiple | Headings and editorial accents | Open source (SIL OFL)[^12] |
| Markazi Text | Text serif | Multiple | Long-form Pashto body in web contexts | Open source (SIL OFL)[^12] |
| Harmattan | Sans | Multiple | Web UI, general text | Open source (SIL OFL)[^12] |
| Tajawal | Sans | Multiple | UI, data-heavy screens | Open source (SIL OFL)[^12] |

As a pragmatic rule, set Noto Sans Arabic as the default UI and body text family, Noto Naskh Arabic for articles and longer reads, and Noto Kufi Arabic for display. Test AGT Pashto Nastaliq and Scheherazade New in brand-forward contexts where a literary or calligraphic tone is appropriate, being careful to maintain legibility in small sizes.[^1][^2][^3][^12][^14]

### Technical considerations: shaping, diacritics, and numerals

Pashto uses a mix of Arabic-Indic and Latin digits across contexts; when supporting both, ensure consistent policy and allow locale-driven selection. Set document directionality at the document root and, if needed, for subcomponents; reserve directional overrides for exceptional cases. Validate that the chosen fonts feature complete glyph sets for Pashto letters and diacritics, and that diacritics render in place without colliding with adjacent letters. Where Nastaliq forms are used, test joining behavior and baseline alignment across browsers and OSes. Finally, favor variable fonts where available to optimize weight and size interpolation and ensure consistent shaping across platforms.[^1][^2][^12][^13]

To operationalize this, Table 5 provides a rendering checklist.

Table 5. Pashto rendering optimization checklist
| Item | What to check | Tooling/notes |
|---|---|---|
| Document direction | dir="rtl" set at root; subcomponents use dir where needed | Structural markup approach for RTL[^18] |
| Numeral policy | Arabic-Indic vs. Latin; locale-driven selection | Validate across product modules |
| Diacritics | Proper mark placement and no collisions | Review with native readers |
| Contextual forms | Initial/medial/final shaping correct | Inspect word clusters visually |
| Glyph coverage | Pashto letters and diacritics present | Noto families provide broad coverage[^1][^2][^12][^13] |
| Variable font features | Weight/size interpolation consistent | Use Noto variable fonts where possible[^1][^13] |
| Webfont delivery | Efficient subsetting and caching | Preload critical faces; fallbacks ready |

### Font Selection and Technical Considerations

Licensing and availability matter for maintainability. The Noto families are open source under SIL OFL and widely distributed via Google Fonts, making them low-friction choices for engineering teams. AGT Pashto Nastaliq is a traditional Nastaliq option for expressive headings but should be vetted for license terms and hinting. A curated set of additional Arabic-script fonts (e.g., Markazi Text, Harmattan, Tajawal) can support varied editorial or UI roles. Table 6 summarizes licensing and distribution characteristics.

Table 6. Font licensing and distribution overview
| Font | License | Distribution | Notes |
|---|---|---|---|
| Noto Sans Arabic | SIL OFL | Google Fonts | Broad weight range, good for UI[^1][^13] |
| Noto Naskh Arabic | SIL OFL | Google Fonts | Long-form readability[^2][^13] |
| Noto Kufi Arabic | SIL OFL | Google Fonts | Display/headings[^3][^13] |
| AGT Pashto Nastaliq | Free (check terms) | Fonts2u | Nastaliq aesthetic[^14] |
| Markazi Text, Harmattan, Tajawal | SIL OFL | Google Fonts | Editorial/UI alternatives[^12] |

### Typography Hierarchy for Pashto Text

A clear hierarchy enables scanning and reduces cognitive load. Material Design’s type system provides a platform-agnostic framework for defining headlines, subtitles, body, captions, and buttons. The hierarchy is communicated through differences in size, weight, and letter spacing, with unit conventions that map across Android (sp), iOS (pt), and Web (rem). Use this framework as the skeleton and tune the sizes and weights to Pashto’s reading comfort, especially for body text and captions.[^4][^1][^2]

To anchor implementation, Table 7 outlines a practical Pashto type scale with units and usage. Sizes can be tuned in design validation with native readers.

Table 7. Pashto type scale plan (platform units)
| Style | Role | Suggested size (Web rem) | Suggested size (Android sp) | Suggested size (iOS pt) | Weight | Usage |
|---|---|---|---|---|---|---|
| Headline 1 | Main page/section title | 2.25–2.75 (tune) | 36–44 | 36–44 | Medium/Semibold | Short, important titles |
| Headline 2 | Subsection title | 2.0–2.25 | 32–36 | 32–36 | Medium | Section headers |
| Headline 3 | Subhead | 1.75–2.0 | 28–32 | 28–32 | Regular/Medium | Group labels |
| Body 1 | Long-form text | 1.0–1.125 | 16–18 | 16–18 | Regular | Paragraphs, articles[^2] |
| Body 2 | Dense UI details | 0.9375–1.0 | 15–16 | 15–16 | Regular | Secondary text |
| Caption | Annotations | 0.8125–0.875 | 13–14 | 13–14 | Regular | Image callouts |
| Button | CTAs | 0.9375–1.0 | 15–16 | 15–16 | Medium | Controls, tabs |

As an implementation detail, rem on the Web is calculated from the root font size; for example, 1.5 rem equals 24 px if the root is 16 px. Letter spacing can be expressed in em for web, sp for Android, and pt for iOS; tune spacing to avoid collisions in diacritic-heavy passages.[^4] When using Noto families, align the variable weight axis to achieve subtle emphasis differences without relying on color alone.[^1][^2]



## RTL Layout Best Practices and Implementation

### Mirroring principles and exceptions

An RTL interface is the mirror image of its LTR counterpart, but not every element should flip. The key principle is to mirror layout and directional elements while preserving semantics for non-directional icons, numbers, and content that is not translated. Navigation stacks, back/forward affordances, and any depiction of time or forward/back movement should be mirrored; meanwhile, numbers in numerals, URLs, non-translated labels, and media transport controls typically remain as in LTR.[^5][^11][^20][^21]

To reduce ambiguity, Table 8 maps common elements to their mirroring behavior.

Table 8. Element mirroring map
| Element | Mirror? | Notes |
|---|---|---|
| Navigation bar order | Yes | Primary actions move to the right; reverse order[^5] |
| Back/forward icons | Yes | Forward points right; back points left in RTL[^5] |
| Text field icons (leading/trailing) | Yes | Swap sides; respect reading direction[^5] |
| Directional arrows | Yes | Mirror arrows indicating flow[^5] |
| Slashes for “off” state | No | Slashes need not mirror[^5] |
| Volume slider | Yes | Slider progresses right; waves from right[^5] |
| Checkbox position | Yes | Checkbox to the right of label[^5] |
| Progress bars | Yes | Fill direction follows reading flow[^5] |
| Numbers (0–9) | No | Keep numerals consistent[^5] |
| URLs, code, product IDs | No | Preserve LTR content as-is[^5] |
| Media playback | No | Playback order is not a reading direction[^5] |
| Time depictions (forward/back) | Yes | Mirror arrows indicating time direction[^5] |

### CSS logical properties and directionality

Use CSS logical properties (margin-inline-start, padding-inline-end, inset-inline-start) so that styles adapt automatically when the direction changes. Set dir="rtl" at the document root for Pashto; apply it to subcomponents only where needed and avoid overloading with brittle directional overrides. The structural markup approach—setting direction in HTML rather than compensating with CSS—simplifies maintenance and improves accessibility.[^15][^16][^18][^17][^5]

To make the shift concrete, Table 9 maps legacy directional properties to logical properties and the expected behavior in RTL.

Table 9. CSS property mapping for RTL
| Legacy property | Logical replacement | RTL behavior |
|---|---|---|
| margin-left | margin-inline-start | Switches to right in RTL[^16] |
| margin-right | margin-inline-end | Switches to left in RTL[^16] |
| padding-left | padding-inline-start | Switches to right in RTL[^16] |
| padding-right | padding-inline-end | Switches to left in RTL[^16] |
| left | inset-inline-start | Right in RTL[^16] |
| right | inset-inline-end | Left in RTL[^16] |
| float: left/right | float: inline-start/end | Direction-aware float[^16] |
| text-align: left/right | text-align: start/end | start aligns right in RTL[^16] |

When integrating with frameworks, consult platform guidance for automatic mirroring in Android, iOS, and Flutter, and adopt the Material Design Web RTL components where available.[^19][^20][^21][^22]

#### Mirroring Rules and Edge Cases

Time and sequence are culturally contingent in UI: forward points right in LTR but left in RTL. For controls that depict the passage of time—breadcrumbs, pagination, steppers—mirror both iconography and motion. For icons with text embedded (e.g., chat bubbles with paragraph marks), ensure alignment with RTL text direction and consider flipping the icon’s internal layout if direction is conveyed visually. Resist the temptation to mirror non-directional metaphors (e.g., camera) or brand assets where mirroring would change meaning.[^5]

#### CSS Strategy and Layout

Adopt logical properties as the default, enforce dir="rtl" at the document root, and layer component-level direction only where required by mixed-direction content. To reduce regressions, consider establishing an RTL style lint rule that flags legacy directional properties (left/right, margin-left/right) and requires the logical counterpart. Several industry guides provide practical examples and pitfalls to avoid.[^15][^16][^17][^18]



## Accessibility in RTL Interfaces

Accessibility begins with language identification and direction, continues through semantic roles and labels, and is verified through multi-modal testing. Explicitly set the language and the document direction; use accessible names and descriptions for controls so that screen readers announce the correct role and state; and test with both automated checks and hands-on sessions using mainstream screen readers to confirm reading order, focus traversal, and labeling integrity.[^23][^24][^25][^26][^28][^27]

Table 10 consolidates a practical accessibility test matrix for RTL Pashto products.

Table 10. RTL accessibility test matrix
| Dimension | What to test | Tools/steps | Pass criteria |
|---|---|---|---|
| Language identification | html lang and direction set | Inspect element; accessibility tree | Language and dir announced; no missing lang[^24][^23] |
| Reading order | Visual order matches DOM order | Screen reader navigation (down/right) | Content reads in logical Pashto sequence[^26] |
| Focus order | Tab/gesture traversal | Keyboard, mobile screen reader | Focus moves sensibly with reading flow[^24] |
| Labeling | Controls have accessible names | aria-label/aria-labelledby; inspect | Names are announced; no duplicates[^25] |
| State descriptions | Toggle states announced | Use ARIA/state attributes | On/off, expanded/collapsed read correctly[^25] |
| Contrast | Text and controls meet WCAG | Automated contrast check; manual | Passes AA/AAA targets for core text |
| Mixed direction content | Embedded LTR behaves correctly | Inspect numbers, URLs | No reading jumps or reordering issues[^5] |
| Screen reader flow | Top-to-bottom reading | NVDA/JAWS/VoiceOver test | Natural order; no surprises[^26][^28] |
| Screen reader scripts | Correct pronunciation | Listen for diacritics/joined forms | No mispronunciations or omissions[^28] |

### ARIA and Labeling for RTL

Accessible naming is the backbone of screen reader usability. Use aria-label to provide concise, unambiguous names for interactive elements; prefer aria-labelledby when there is visible on-screen text that should serve as the primary label. For complex controls, provide state descriptions with ARIA so that toggles, expansions, and selections are announced properly. Maintain a one-to-one mapping between visible controls and their programmatic names, and avoid overloading controls with the same name but different roles.[^25][^24]

### Screen Reader and Testing Workflow

Choose a representative set of tools—NVDA or JAWS on Windows, and VoiceOver on macOS/iOS—for baseline coverage. Build a script that verifies reading order, focus traversal, labeling, and state announcement in both pure RTL and mixed-direction scenarios. Address the common failure mode where poor HTML structure undermines RTL reading; fix the DOM order and rely on CSS logical properties, rather than compensating with brittle direction overrides. Document issues in a test log that maps failures to fixes and revalidate after each major RTL change.[^28][^26][^24]



## Cultural UX Considerations for Afghan Users

### Tone, clarity, and cognitive load

Localization is more than translation. For Afghan and broader Pakistani audiences, a serious, straightforward tone tends to be preferred over playful or humorous styles, especially in professional, civic, and utility products. This preference suggests minimizing wordiness, using clear section headings, and avoiding idioms that may not carry across. Such stylistic choices reduce cognitive load and help users move quickly to task completion.[^29][^30][^31]

Information density should be thoughtfully managed. A dense, information-rich layout may be welcomed in some contexts (e.g., dashboards and portals) if it remains scannable through typographic hierarchy and clear grouping. In transactional flows (e.g., forms, payments), reduce cognitive load with chunked steps, clear affordances, and explicit validation feedback.

Table 11 synthesizes cultural UX guidelines into actionable do/don’t patterns for Pashto products.

Table 11. Cultural UX do/don’ts for Afghan users
| Area | Do | Don’t |
|---|---|---|
| Tone | Use serious, respectful, and clear language | Overuse humor, slang, or idioms[^29][^30] |
| Headings | Make headings scannable and informative | Hide key actions behind vague labels[^31] |
| Content density | Provide rich info with clear grouping | Flood screens with unbroken text[^29] |
| Validation | Give explicit, actionable error messages | Use generic or playful error text |
| Navigation | Keep primary actions to the right; back on right | Mix LTR and RTL affordances without clear cues |
| Icons | Mirror directional icons; avoid text-laden icons | Mirror non-directional metaphors (e.g., camera)[^5] |
| Imagery | Use subtle, respectful cultural motifs | Overpower UI with large textile patterns |

### Localization Quality and Evaluation

Localization should be validated with native speakers across both reading and interaction tasks. Instrument tests with task success rates, time on task, and error rates, and run error-propensity analyses on forms. A localization quality assurance (LQA) scorecard can help teams track severity levels and fix velocity across release cycles. Include a Pashto UX pattern checklist in the scorecard—directionality, numerals, icon mirroring, and diacritic rendering—alongside copy and interaction audits.[^32][^31]

Table 12 proposes an LQA scorecard structure.

Table 12. Localization QA scorecard
| Dimension | Metrics | Severity scale | Acceptance criteria |
|---|---|---|---|
| Functional | Task success, crash-free sessions | Blocker/Critical/Major/Minor | ≥ 95% success on P0 flows |
| Linguistic | Accuracy, tone, terminology | … | Native review sign-off |
| UI layout | Mirroring, spacing, alignment | … | Zero critical mirroring defects |
| Typography | Legibility, diacritics, scale | … | No legibility regressions |
| Accessibility | Reading order, labels, contrast | … | Pass WCAG AA for core flows |
| Performance | TTI, font swap, CLS | … | Meets performance budgets |



## Modern Interpretation of Traditional Afghan Art in Digital Interfaces

Tradition thrives when it is translated, not copied. Contemporary Afghan art offers a clear pathway: borrow structure, reduce complexity, and foreground clarity. For instance, Shaheer Zazai’s digital works translate the grammar of carpet weaving—knots, repeat units, borders—into pixel grids and typographic layouts, creating interfaces that feel both familiar and new. This approach can inspire pattern systems and brand marks that are distinctly Afghan yet clearly designed for screens.[^33][^34][^35]

Two guardrails matter most. First, keep a safe separation between motifs and text: apply patterns at low opacity and ensure they do not degrade the legibility of Pashto. Second, respect the geometry’s rhythm. Islamic and Afghan geometric systems rely on symmetry and repetition; when abstracted for UI, these become a source of calm and order rather than visual spectacle.[^9]

Table 13 outlines how to map traditional patterns to modern design tokens.

Table 13. Traditional-to-digital design token mapping
| Traditional element | Digital analog | Usage | Guardrails |
|---|---|---|---|
| Field repeat (geometric) | Background texture token | Cards, dashboards | Opacity scale; contrast limits |
| Border (kilim edge) | Divider token | Section markers | Thin stroke; consistent rhythm |
| Tribal gul | Accent badge | Identity markers | Small surfaces only |
| Tree of Life (narrative) | Illustration token | Onboarding, empty states | Keep off dense text areas |

### Case Study: Zazai’s Digital Carpets

Zazai’s practice recreates the logic of weaving within Microsoft Word, translating knots into character grids and orchestrating repeats as page layouts. The lesson for interface design is structural: use grid logic, repeat units, and borders to echo textile composition, but adapt to a digital rhythm—larger negative space, calmer chroma, and restrained coverage. Apply these lessons in UI by building pattern libraries that echo the precision of weaving while ensuring that Pashto text always dominates the visual hierarchy.[^34][^35]



## Implementation Roadmap and Risk Controls

A disciplined rollout reduces risk and accelerates adoption. The roadmap below sequences the key activities and embeds validation steps.

Table 14. Implementation checklist and timeline
| Phase | Milestones | Owners | Acceptance criteria |
|---|---|---|---|
| Foundations | Define dir=rtl at root; tokenize colors, spacing, type; select Noto families | Design, Eng | dir set; tokens in code; font assets integrated[^1][^2][^3] |
| RTL adoption | Replace left/right with logical properties; mirror icons; refactor components | Eng | RTL lint passes; component parity with LTR[^15][^16] |
| Patterns | Build motif tiles; define opacity/contrast scales; integrate tokens | Design | Motif tokens documented; no text interference[^8][^9] |
| Accessibility | Add lang attributes; ARIA labels; create test scripts; run audits | QA, Eng | Test matrix passes; no critical issues[^24][^25][^26] |
| Localization | LQA scorecard; native reviews; fix SLOs | PM, L10n | ≥ 95% P0 success; sign-off[^32] |
| Validation | Heuristic + user testing in Pashto; performance checks | Design, QA | Meets usability and perf goals |
| Rollout | Gradual release; telemetry; bug triage | PM, Eng | No blocker regressions |

Risk controls center on predictable failure modes in RTL products. Table 15 lists common risks and mitigations.

Table 15. Risk register for RTL/Pashto products
| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|
| Incorrect mirroring (directional icons) | Medium | High | Mirror map and icon audit | Design/Eng[^5] |
| Misordered DOM causing reading jumps | High | High | Enforce structural RTL; fix DOM order | Eng[^24][^28] |
| Numeral inconsistency | Medium | Medium | Define locale policy; test modules | PM/Eng |
| Diacritic collision or poor shaping | Medium | High | Font/shaping QA with native readers | Design/QA[^1][^2] |
| Pattern interference with text | Medium | Medium | Contrast guardrails; text-first review | Design[^8][^9] |
| Screen reader mislabeling | Medium | High | ARIA labels and test scripts | Eng/QA[^25][^26] |
| Performance regressions (webfonts) | Medium | Medium | Subsetting; preload; fallback | Eng[^13] |



## Known Information Gaps and Next Steps

Several areas require targeted research to ensure Afghan users receive a best-in-class experience:

- Legibility metrics: Conduct empirical tests comparing Pashto typefaces and sizes for on-screen reading (e.g., optimal sizes, line lengths, diacritic clarity). Build on the type scale proposed here to validate with native readers.[^4]
- Color contrast: Validate proposed palettes against WCAG targets in both light and dark modes with real Pashto text and common devices.
- Numerals: Establish product policy for Arabic-Indic vs. Latin digits in Pashto and test user comprehension across domains (e.g., finance, education).
- Screen reader testing: Expand testing to include Pashto with JAWS, NVDA, VoiceOver, and mobile readers, focusing on pronunciation of joined forms and diacritics.[^28]
- Pattern licensing: Audit sources and rights for motif assets; prefer original research and documentation over uncredited aggregations.
- User research: Gather Afghan user preferences for tone, layout density, navigation expectations, and iconography beyond general cross-cultural heuristics.
- Platform differences: Validate CSS logical properties and text rendering across Android, iOS, and web in Pashto contexts; document any platform-specific workarounds.

These activities should be scheduled as research sprints during the foundations phase, with findings folded back into the design system and engineering standards.



## References

[^1]: Noto Sans Arabic - Google Fonts. https://fonts.google.com/noto/specimen/Noto+Sans+Arabic  
[^2]: Noto Naskh Arabic - Google Fonts. https://fonts.google.com/noto/specimen/Noto+Naskh+Arabic  
[^3]: Noto Kufi Arabic - Google Fonts. https://fonts.google.com/noto/specimen/Noto+Kufi+Arabic  
[^4]: The type system - Material Design. https://m2.material.io/design/typography/the-type-system.html  
[^5]: Bidirectionality - Material Design. https://m2.material.io/design/usability/bidirectionality.html  
[^6]: Afghan Dress: Embrace the Elegance of Afghan Culture - Aseel Foundation. https://aseelfoundation.org/afghan-dress/  
[^7]: The Afghan Rug - history, origin & composition - James Barclay. https://jamesbarclay.co.uk/the-afghan-rug/  
[^8]: Symbolism of Afghan Rug Designs - Rugnify. https://rugnify.com/blogs/the-journey-of-an-afghan-hand-knotted-rug/weaving-stories-thread-by-thread-the-symbolism-of-afghan-rug-designs  
[^9]: Geometric Patterns in Islamic Art - The Metropolitan Museum of Art. https://www.metmuseum.org/essays/geometric-patterns-in-islamic-art  
[^10]: Afghanistan Ethnographic Art: Turkoman Embroidery - Cultural Property News. https://culturalpropertynews.org/afghanistan-ethnographic-art-turkoman-embroidery/  
[^11]: Languages using right-to-left scripts - W3C. https://www.w3.org/International/questions/qa-scripts  
[^12]: 27 Best Free Pashto Language Fonts - Font Advice. https://fontadvice.com/font-collections/pashto-language-fonts/  
[^13]: Use Noto fonts - Noto Docs. https://notofonts.github.io/noto-docs/website/use/  
[^14]: AGT Pashto Nastaliq font - Fonts2u. https://fonts2u.com/agt-pashto-nastaliq.font  
[^15]: Right-to-left Styling 101 - CSS-Tricks. https://css-tricks.com/rtl-styling-101/  
[^16]: Right-to-left Styling - RTL Styling 101 (Ahmad Shadeed). https://rtlstyling.com/posts/rtl-styling/  
[^17]: 7 Expert Tips for Better RTL Web Design - Weglot. https://www.weglot.com/blog/rtl-web  
[^18]: Structural markup and right-to-left text in HTML - W3C. https://www.w3.org/International/questions/qa-html-dir  
[^19]: Support layout mirroring - Android Developers. https://developer.android.com/training/basics/supporting-devices/languages#SupportLayoutMirroring  
[^20]: Supporting Right-to-Left Languages - Apple Developer. https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPInternational/SupportingRight-To-LeftLanguages/SupportingRight-To-LeftLanguages.html  
[^21]: RTL (Right-to-left) components - Material Design Web. https://material.io/develop/web/components/rtl/  
[^22]: Directionality class - Flutter API. https://api.flutter.dev/flutter/widgets/Directionality-class.html  
[^23]: Identify Languages of HTML Documents - Deque University. https://dequeuniversity.com/tips/identify-languages  
[^24]: ARIA - Accessibility - MDN Web Docs. https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA  
[^25]: ARIA6: Using aria-label to provide labels for objects - W3C. https://www.w3.org/TR/WCAG20-TECHS/ARIA6.html  
[^26]: Right-to-left (RTL) Languages - Smartling Help Center. https://help.smartling.com/hc/en-us/articles/1260802028830-Right-to-left-RTL-Languages  
[^27]: In which direction does a screenreader read dir="rtl"? - Stack Overflow. https://stackoverflow.com/questions/20404556/in-which-direction-does-a-screenreader-read-dir-rtl  
[^28]: Overcoming Challenges in Right-to-Left Language Testing - WonderProxy. https://wonderproxy.com/blog/overcoming-challenges-in-right-to-left-language-testing/  
[^29]: Comparison of cultural preferences and cultural practices in website design in Pakistan - Springer. https://link.springer.com/article/10.1007/s10209-025-01248-w  
[^30]: Modify Your Design for Global Audiences: Crosscultural UX Design - Nielsen Norman Group. https://www.nngroup.com/articles/crosscultural-design/  
[^31]: UX Design Across Different Cultures — Part 1 - Prototypr. https://blog.prototypr.io/ux-design-across-different-cultures-part-1-1caa12a504c0  
[^32]: How to translate RTL languages: Best practices for localization - Smartling. https://www.smartling.com/blog/translate-rtl-languages  
[^33]: Pixelated: How Shaheer Zazai Digitalized Afghan Carpets - AJAMMC. https://ajammc.com/2019/01/30/pixelated-shaheer-zazai-digitalized-afghan-carpets/  
[^34]: Shaheer Zazai: Digital Images - Textile Museum of Canada. https://textilemuseum.ca/gathering/shaheer-zazai-digital-images/  
[^35]: Afghanistan My Love - Aga Khan Museum. https://agakhanmuseum.org/whats-on/afghanistan-my-love/